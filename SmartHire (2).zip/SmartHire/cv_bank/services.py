"""
SmartHire AI CV Parser — Powered by Google Gemini API + PyPDF2
Extracts structured profile data from uploaded CV/resume PDFs.
"""
import re
import json
import math
import os
from collections import Counter

import PyPDF2

# Gemini API integration
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

# Configure Gemini
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')
if GEMINI_AVAILABLE and GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)


def extract_text_from_pdf(pdf_file):
    """Extract raw text from a PDF file."""
    text = ""
    try:
        reader = PyPDF2.PdfReader(pdf_file)
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    except Exception as e:
        print(f"Error reading PDF: {e}")
    return text


def parse_cv_with_gemini(text):
    """
    Use Google Gemini API to intelligently parse CV text into structured data.
    Returns a dict with all extracted profile fields.
    """
    if not GEMINI_AVAILABLE or not GEMINI_API_KEY:
        print("Gemini API not available, falling back to regex parser")
        return parse_cv_with_regex(text)
    
    try:
        model = genai.GenerativeModel('gemini-2.0-flash')
        
        prompt = f"""You are an expert CV/Resume parser for a recruitment platform called SmartHire.
Analyze the following CV text and extract structured information.

Return ONLY a valid JSON object with these exact keys (no markdown, no explanation):
{{
    "full_name": "extracted full name",
    "email": "extracted email or empty string",
    "phone": "extracted phone or empty string",
    "location": "city, country or empty string",
    "bio": "A 2-3 sentence professional summary based on the CV content",
    "skills": ["skill1", "skill2", ...],
    "total_experience_years": integer (best estimate, 0 if fresh graduate),
    "degree": "highest degree (e.g. Bachelors, Masters, PhD, or Not Specified)",
    "education": [
        {{"institution": "name", "degree": "degree type", "field": "field of study", "year": "graduation year or expected"}}
    ],
    "work_experience": [
        {{"company": "name", "role": "job title", "duration": "start - end", "description": "brief description"}}
    ],
    "certifications": ["cert1", "cert2", ...],
    "languages": ["lang1", "lang2", ...],
    "linkedin_url": "extracted linkedin URL or empty string",
    "github_url": "extracted github URL or empty string",
    "portfolio_url": "extracted portfolio URL or empty string"
}}

Important rules:
- For skills, extract SPECIFIC technical skills (programming languages, frameworks, tools), not vague phrases
- Capitalize skill names properly (e.g. "Python", "React", "AWS", "Docker")
- If a section is missing from the CV, use empty string or empty list
- Experience years: count from the earliest work entry to now, or estimate from graduation year
- Do NOT hallucinate information that isn't in the CV

CV TEXT:
{text[:8000]}
"""
        
        response = model.generate_content(prompt)
        response_text = response.text.strip()
        
        # Clean markdown code blocks if present
        if response_text.startswith('```'):
            response_text = re.sub(r'^```(?:json)?\s*', '', response_text)
            response_text = re.sub(r'\s*```$', '', response_text)
        
        parsed = json.loads(response_text)
        return {
            'full_name': parsed.get('full_name', ''),
            'email': parsed.get('email', ''),
            'phone': parsed.get('phone', ''),
            'location': parsed.get('location', ''),
            'bio': parsed.get('bio', ''),
            'skills': parsed.get('skills', []),
            'total_experience_years': int(parsed.get('total_experience_years', 0)),
            'degree': parsed.get('degree', 'Not Specified'),
            'education': parsed.get('education', []),
            'work_experience': parsed.get('work_experience', []),
            'certifications': parsed.get('certifications', []),
            'languages': parsed.get('languages', []),
            'linkedin_url': parsed.get('linkedin_url', ''),
            'github_url': parsed.get('github_url', ''),
            'portfolio_url': parsed.get('portfolio_url', ''),
        }
        
    except Exception as e:
        print(f"Gemini API error: {e}, falling back to regex parser")
        return parse_cv_with_regex(text)


def parse_cv_with_regex(text):
    """Fallback regex-based parser when Gemini is unavailable."""
    return {
        'full_name': '',
        'email': _extract_email(text),
        'phone': '',
        'location': '',
        'bio': '',
        'skills': extract_skills_from_text(text),
        'total_experience_years': extract_experience_years(text),
        'degree': extract_degree(text),
        'education': [],
        'work_experience': [],
        'certifications': [],
        'languages': [],
        'linkedin_url': '',
        'github_url': '',
        'portfolio_url': '',
    }


def _extract_email(text):
    match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', text)
    return match.group(0) if match else ''


# ═══════════════════════════════════════════════════
# SKILL EXTRACTION (Expanded Taxonomy — 200+ skills)
# ═══════════════════════════════════════════════════

SKILL_TAXONOMY = {
    'Programming Languages': [
        'python', 'java', 'javascript', 'typescript', 'c++', 'c#', 'c',
        'ruby', 'php', 'swift', 'kotlin', 'go', 'rust', 'scala', 'r',
        'matlab', 'perl', 'dart', 'lua', 'haskell', 'elixir', 'clojure',
        'objective-c', 'assembly', 'vba', 'groovy', 'bash', 'powershell',
    ],
    'Web Frameworks': [
        'django', 'flask', 'fastapi', 'react', 'angular', 'vue.js', 'vue',
        'next.js', 'nuxt.js', 'express', 'node.js', 'spring boot', 'spring',
        'asp.net', '.net', 'rails', 'laravel', 'symfony', 'gatsby',
        'svelte', 'remix', 'ember.js',
    ],
    'Mobile': [
        'android', 'ios', 'flutter', 'react native', 'swift ui', 'swiftui',
        'jetpack compose', 'xamarin', 'ionic', 'cordova',
    ],
    'Data Science & AI': [
        'machine learning', 'deep learning', 'data science', 'nlp',
        'computer vision', 'tensorflow', 'pytorch', 'keras', 'scikit-learn',
        'pandas', 'numpy', 'scipy', 'opencv', 'hugging face', 'transformers',
        'llm', 'generative ai', 'neural networks', 'reinforcement learning',
        'xgboost', 'lightgbm', 'catboost', 'spark mllib',
    ],
    'Cloud & DevOps': [
        'aws', 'azure', 'gcp', 'google cloud', 'docker', 'kubernetes',
        'terraform', 'ansible', 'jenkins', 'github actions', 'ci/cd',
        'devops', 'cloudformation', 'helm', 'argocd', 'prometheus',
        'grafana', 'datadog', 'new relic', 'nginx', 'apache',
    ],
    'Databases': [
        'sql', 'mysql', 'postgresql', 'mongodb', 'redis', 'elasticsearch',
        'cassandra', 'dynamodb', 'firebase', 'supabase', 'sqlite',
        'oracle', 'mssql', 'neo4j', 'couchdb', 'influxdb',
    ],
    'Data Engineering': [
        'kafka', 'spark', 'hadoop', 'airflow', 'dbt', 'snowflake',
        'bigquery', 'redshift', 'databricks', 'flink', 'nifi',
        'etl', 'data pipeline', 'data warehouse',
    ],
    'Tools & Platforms': [
        'git', 'github', 'gitlab', 'bitbucket', 'jira', 'confluence',
        'slack', 'postman', 'swagger', 'figma', 'adobe xd', 'sketch',
        'photoshop', 'illustrator', 'blender', 'unity', 'unreal engine',
        'tableau', 'power bi', 'looker', 'excel', 'sas',
    ],
    'Methodologies': [
        'agile', 'scrum', 'kanban', 'waterfall', 'tdd', 'bdd',
        'microservices', 'rest api', 'graphql', 'grpc', 'soap',
        'event-driven', 'serverless', 'oauth', 'jwt',
    ],
    'Soft Skills': [
        'leadership', 'communication', 'teamwork', 'problem solving',
        'critical thinking', 'project management', 'mentoring',
        'public speaking', 'negotiation', 'time management',
    ],
}

ALL_SKILLS = []
for category, skills in SKILL_TAXONOMY.items():
    ALL_SKILLS.extend(skills)


def extract_skills_from_text(text):
    """Extract skills using the expanded taxonomy."""
    found_skills = []
    text_lower = text.lower()
    for skill in ALL_SKILLS:
        pattern = r'\b' + re.escape(skill) + r'\b'
        if re.search(pattern, text_lower):
            # Proper capitalization
            if len(skill) <= 3:
                found_skills.append(skill.upper())
            else:
                found_skills.append(skill.title())
    return list(set(found_skills))


def extract_experience_years(text):
    """Extract years of experience from text."""
    patterns = [
        r'(\d+)\+?\s*years?\s*(?:of\s*)?experience',
        r'(\d+)\+?\s*yrs?\s*exp',
        r'experience\s*[:\-]?\s*(\d+)\s*years?',
    ]
    max_years = 0
    for pattern in patterns:
        matches = re.findall(pattern, text.lower())
        for match in matches:
            try:
                years = int(match)
                if 0 < years < 40 and years > max_years:
                    max_years = years
            except (ValueError, TypeError):
                pass
    return max_years


def extract_degree(text):
    """Extract the highest degree from text."""
    text_lower = text.lower()
    if 'phd' in text_lower or 'ph.d' in text_lower or 'doctorate' in text_lower:
        return 'PhD'
    if 'master' in text_lower or 'msc' in text_lower or 'm.s.' in text_lower or 'mba' in text_lower:
        return 'Masters'
    if 'bachelor' in text_lower or 'bsc' in text_lower or 'b.s.' in text_lower or 'b.tech' in text_lower or 'bscs' in text_lower:
        return 'Bachelors'
    if 'diploma' in text_lower or 'associate' in text_lower:
        return 'Diploma'
    return 'Not Specified'


# ═══════════════════════════════════════════════════
# MATCHING & SCORING ALGORITHMS
# ═══════════════════════════════════════════════════

def get_cosine_similarity(vec1, vec2):
    """Compute cosine similarity between two Counter vectors."""
    intersection = set(vec1.keys()) & set(vec2.keys())
    numerator = sum(vec1[x] * vec2[x] for x in intersection)
    sum1 = sum(vec1[x] ** 2 for x in vec1)
    sum2 = sum(vec2[x] ** 2 for x in vec2)
    denominator = math.sqrt(sum1) * math.sqrt(sum2)
    return float(numerator) / denominator if denominator else 0.0


def calculate_match_score(candidate_skills, required_skills):
    """Calculate match score between candidate and job skills."""
    if not required_skills or not candidate_skills:
        return 0.0
    
    if isinstance(required_skills, str):
        required_skills = [s.strip().lower() for s in required_skills.split(',')]
    if isinstance(candidate_skills, str):
        candidate_skills = [s.strip().lower() for s in candidate_skills.split(',')]
    if isinstance(required_skills, list):
        required_skills = [s.lower() if isinstance(s, str) else str(s).lower() for s in required_skills]
    if isinstance(candidate_skills, list):
        candidate_skills = [s.lower() if isinstance(s, str) else str(s).lower() for s in candidate_skills]
        
    vec1 = Counter(candidate_skills)
    vec2 = Counter(required_skills)
    
    return round(get_cosine_similarity(vec1, vec2) * 100, 2)


def verify_cv_authenticity(text):
    """Verify if a document looks like a legitimate CV."""
    if not text or len(text) < 150:
        return False, "Document too short to be a valid CV."

    text_lower = text.lower()
    markers = [
        'education', 'experience', 'skills', 'projects',
        'contact', 'summary', 'profile', 'work history',
        'university', 'degree', 'employment', 'objective',
        'certification', 'achievement', 'reference', 'volunteer',
    ]
    
    found_markers = [m for m in markers if re.search(r'\b' + m + r'\b', text_lower)]
    score = len(found_markers)
    is_authentic = score >= 3
    
    if is_authentic:
        message = f"CV authenticated successfully. ({score} professional markers detected)"
    else:
        message = f"Warning: This document may not be a standard CV. Only {score} marker(s) found."
    
    return is_authentic, message


def generate_cover_letter_with_gemini(job, candidate_profile):
    """Generate a personalized cover letter using Gemini API."""
    if not GEMINI_AVAILABLE or not GEMINI_API_KEY:
        return _generate_template_cover_letter(job, candidate_profile)
    
    try:
        model = genai.GenerativeModel('gemini-2.0-flash')
        
        skills = candidate_profile.extracted_skills_json if isinstance(candidate_profile.extracted_skills_json, list) else []
        job_skills = job.required_skills_json if isinstance(job.required_skills_json, list) else []
        
        prompt = f"""Write a professional cover letter for a job application.

Candidate:
- Name: {candidate_profile.user.full_name or candidate_profile.user.username}
- Skills: {', '.join(skills)}
- Experience: {candidate_profile.total_experience} years
- Degree: {candidate_profile.degree_extracted}
- Bio: {candidate_profile.bio}

Job:
- Title: {job.title}
- Company: {job.company}
- Required Skills: {', '.join(job_skills)}
- Description: {job.description[:500]}

Write a compelling, professional cover letter (250-350 words).
Do NOT use placeholders like [Your Name]. Use the actual data provided.
Be specific about how the candidate's skills match the job requirements."""
        
        response = model.generate_content(prompt)
        return response.text.strip()
        
    except Exception as e:
        print(f"Gemini cover letter error: {e}")
        return _generate_template_cover_letter(job, candidate_profile)


def _generate_template_cover_letter(job, candidate_profile):
    """Fallback template-based cover letter generation."""
    name = candidate_profile.user.full_name or candidate_profile.user.username
    skills = candidate_profile.extracted_skills_json if isinstance(candidate_profile.extracted_skills_json, list) else []
    job_skills = job.required_skills_json if isinstance(job.required_skills_json, list) else []
    matching = set(s.lower() for s in skills) & set(s.lower() for s in job_skills)
    
    return f"""Dear Hiring Manager,

I am writing to express my strong interest in the {job.title} position at {job.company}. With {candidate_profile.total_experience} years of professional experience and a {candidate_profile.degree_extracted} degree, I am confident in my ability to contribute meaningfully to your team.

My technical skill set includes {', '.join(skills[:8])}{'...' if len(skills) > 8 else ''}, which aligns well with your requirements. {'I am particularly strong in ' + ', '.join(list(matching)[:5]) + ', which are directly relevant to this role.' if matching else ''}

I would welcome the opportunity to discuss how my experience and skills can benefit {job.company}. Thank you for considering my application.

Best regards,
{name}"""
